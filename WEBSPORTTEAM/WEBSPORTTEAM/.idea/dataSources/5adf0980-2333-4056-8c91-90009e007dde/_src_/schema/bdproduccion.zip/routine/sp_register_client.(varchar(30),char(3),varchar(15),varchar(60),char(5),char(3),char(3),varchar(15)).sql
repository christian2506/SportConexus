CREATE PROCEDURE `sp_register_client`(`nombreCli`  VARCHAR(30), `codRubro` CHAR(3), `telefono` VARCHAR(15),
                                      `correo`     VARCHAR(60), `codEmp` CHAR(5), `codServicio` CHAR(3),
                                      `codTipoCom` CHAR(3), `nivelInt` VARCHAR(15))
  BEGIN
    DECLARE contador 	INT;
    DECLARE contador2 	INT;
    DECLARE contador3 	INT;
    DECLARE newCodigo 	CHAR(6);
    DECLARE newCodigo2 	CHAR(5);
    DECLARE newCodigo3 	CHAR(6);
    BEGIN
        SET contador = (SELECT COUNT(*)+1 FROM Cliente); 
        IF(contador<10)THEN
            SET newCodigo = CONCAT('C0000',contador);
			ELSE IF(contador<100) THEN
				SET newCodigo = CONCAT('C000',contador);
				ELSE IF(contador<1000)THEN
					SET newCodigo = CONCAT('C00',contador);
					ELSE IF(contador<10000)THEN
						SET newCodigo = CONCAT('C0',contador);
                        ELSE IF(contador<100000)THEN
							SET newCodigo = CONCAT('C',contador);
						END IF;
					END IF;
				END IF;
			END IF; 
		END IF;
	END;
    
    BEGIN
        SET contador2 = (SELECT COUNT(*)+1 FROM Actividad); 
        IF(contador2<10)THEN
            SET newCodigo2 = CONCAT('A000',contador2);
			ELSE IF(contador2<100) THEN
				SET newCodigo2 = CONCAT('A00',contador2);
				ELSE IF(contador2<1000)THEN
					SET newCodigo2 = CONCAT('A0',contador2);
					ELSE IF(contador2<10000)THEN
						SET newCodigo2 = CONCAT('A',contador2);
					END IF;
				END IF;
			END IF; 
		END IF;
	END;
    
    BEGIN
        SET contador3 = (SELECT COUNT(*)+1 FROM Detalle_Actividad); 
        IF(contador3<10)THEN
            SET newCodigo3 = CONCAT('D0000',contador3);
			ELSE IF(contador3<100) THEN
				SET newCodigo3 = CONCAT('D000',contador3);
				ELSE IF(contador3<1000)THEN
					SET newCodigo3 = CONCAT('D00',contador3);
					ELSE IF(contador3<10000)THEN
						SET newCodigo3 = CONCAT('D0',contador3);
                        ELSE IF(contador3<100000)THEN
							SET newCodigo3 = CONCAT('D',contador3);
						END IF;
					END IF;
				END IF;
			END IF; 
		END IF;
	END;
    
    BEGIN
		INSERT INTO Cliente   VALUES (newCodigo, nombreCli, codRubro, telefono, correo);
        INSERT INTO Actividad VALUES (newCodigo2, codEmp, newCodigo, now(), 'asdasd');
        INSERT INTO Detalle_Actividad VALUES (newCodigo3, newCodigo2, codServicio, codTipoCom, nivelInt, now());
    END;
END