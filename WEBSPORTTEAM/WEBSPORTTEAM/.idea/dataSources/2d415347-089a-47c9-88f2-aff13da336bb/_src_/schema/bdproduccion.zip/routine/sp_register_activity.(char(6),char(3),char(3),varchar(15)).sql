CREATE PROCEDURE `sp_register_activity`(`codCli`   CHAR(6), `codServicio` CHAR(3), `codTipoCom` CHAR(3),
                                        `nivelInt` VARCHAR(15))
  BEGIN
	DECLARE codActivity CHAR(5);
    DECLARE contador 	INT;
    DECLARE newCodigo 	CHAR(6);
    
    BEGIN
        SET contador = (SELECT COUNT(*)+1 FROM Detalle_Actividad); 
        SET codActivity = (SELECT Cod_Actividad FROM Actividad WHERE Cod_Cliente = codCli);
                            
        IF(contador<10)THEN
            SET newCodigo = CONCAT('D0000',contador);
			ELSE IF(contador<100) THEN
				SET newCodigo = CONCAT('D000',contador);
				ELSE IF(contador<1000)THEN
					SET newCodigo = CONCAT('D00',contador);
					ELSE IF(contador<10000)THEN
						SET newCodigo = CONCAT('D0',contador);
                        ELSE IF(contador<100000)THEN
							SET newCodigo = CONCAT('D',contador);
						END IF;
					END IF;
				END IF;
			END IF; 
		END IF;
	END;
    
    
    BEGIN
        INSERT INTO Detalle_Actividad VALUES (newCodigo, codActivity, codServicio, codTipoCom, nivelInt, now());
    END;
END